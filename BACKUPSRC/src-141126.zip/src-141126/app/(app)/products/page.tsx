import Link from "next/link";
import { prisma } from "@/lib/db/prisma";
import { requireAuth } from "@/lib/auth/session";
import { PageHeader } from "@/components/ui/PageHeader";
import Barcode from "./Barcode";

export default async function Products() {
  await requireAuth();
  const products = await prisma.product.findMany({
    where: { isActive: true },
    include: { category: true, variants: { where: { isActive: true }, take: 1 } },
    orderBy: { name: "asc" }, take: 200,
  });
  return <div className="space-y-4">
    <PageHeader title="Products" subtitle="Manage your shared product catalogue. Add or print barcode stickers for product labels." action={<Link href="/products/new" className="rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white">+ Add Product</Link>} />
    <div className="overflow-x-auto rounded-2xl bg-white ring-1 ring-slate-200">
      <table className="min-w-full text-sm"><thead className="bg-slate-50"><tr>
        {["Product","SKU","Category","Type","Selling Price","Barcode sticker",""].map(h=><th key={h} className="px-4 py-3 text-left">{h}</th>)}
      </tr></thead><tbody className="divide-y">
        {products.map(p=>{const v=p.variants[0];return <tr key={p.id}>
          <td className="px-4 py-3 font-medium">{p.name}</td><td className="px-4 py-3">{p.sku}</td><td className="px-4 py-3">{p.category.name}</td><td className="px-4 py-3">{p.productType}</td><td className="px-4 py-3">₹{Number(v?.sellingPrice??0).toLocaleString("en-IN")}</td><td className="px-4 py-3"><Barcode value={p.barcode||p.sku} productName={p.name}/></td><td className="px-4 py-3 text-right"><Link className="text-blue-700" href={`/products/${p.id}/edit`}>Edit</Link></td>
        </tr>})}
      </tbody></table>
    </div>
    <p className="text-xs text-slate-500">Sticker size: 50 × 25 mm (same as the compact Small Job Card). In the print dialog, choose your label printer or Save as PDF.</p>
  </div>;
}
