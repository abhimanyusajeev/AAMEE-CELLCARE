"use client";
import { useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { CheckCircle2, MessageCircle, PackagePlus, Send, Wrench } from "lucide-react";
import { buildWhatsAppLink } from "@/lib/whatsapp";

const statuses = [
  ["RECEIVED", "Received"], ["DIAGNOSIS", "Inspection"], ["WAITING_FOR_CUSTOMER_APPROVAL", "Awaiting Approval"], ["WAITING_FOR_PARTS", "Waiting for Parts"], ["REPAIRING", "Repair In Progress"], ["READY_FOR_PICKUP", "Ready for Delivery"], ["DELIVERED", "Delivered"], ["CANCELLED", "Cancelled"],
] as const;
const inspectionItems = ["Display", "Touch", "Front Camera", "Rear Camera", "Speaker", "Microphone", "Earpiece", "Wi-Fi", "Bluetooth", "Charging Port", "Battery", "Fingerprint / Face ID", "Buttons", "Body / Frame"];
const statusLabel = Object.fromEntries(statuses);

export function RepairDetail({ repair, technicians, products }: { repair: any; technicians: any[]; products: any[] }) {
  const router = useRouter();
  const [row, setRow] = useState(repair);
  const [saving, setSaving] = useState(false);
  const [note, setNote] = useState(""); const [toast, setToast] = useState("");
  const [accessory, setAccessory] = useState("");
  const [partId, setPartId] = useState("");
  const [partQty, setPartQty] = useState("1");
  const [partSearch, setPartSearch] = useState("");
  const [partPickerOpen, setPartPickerOpen] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState(row.status);
  const [estimateEdit, setEstimateEdit] = useState(String(row.approvedAmount ?? row.estimate ?? 0));
  const [discountEdit, setDiscountEdit] = useState(String(row.discountAmount ?? 0));
  const [advanceEdit, setAdvanceEdit] = useState(String(row.advanceAmount ?? 0));
  const currentInspection = useMemo(() => Object.fromEntries((row.inspections ?? []).map((x: any) => [x.item, x.status])), [row.inspections]);

  async function patch(payload: any) {
    setSaving(true); setToast("");
    const r = await fetch(`/api/repairs/${row.id}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
    const data = await r.json().catch(() => ({}));
    setSaving(false);
    if (!r.ok) { setToast(data.message || "Unable to save"); return; }
    setRow(data.repair); setSelectedStatus(data.repair.status); setEstimateEdit(String(data.repair.approvedAmount ?? data.repair.estimate ?? 0)); setDiscountEdit(String(data.repair.discountAmount ?? 0)); setAdvanceEdit(String(data.repair.advanceAmount ?? 0)); router.refresh(); setToast(data.whatsapp?.sent ? "Saved and WhatsApp update sent." : "Saved successfully.");
  }

  async function addAccessory() { if (!accessory.trim()) return; await patch({ addAccessory: { name: accessory.trim(), quantity: 1 } }); setAccessory(""); }
  async function addPart() { if (!partId) return; await patch({ addPart: { productVariantId: partId, quantity: Number(partQty || 1) } }); setPartId(""); setPartQty("1"); }
  function openWhatsApp(stage: "created" | "completed" | "pickup" | "bill") {
    const phone = row.customer?.phone;
    if (!phone) { setToast("Customer phone number is missing."); return; }

    const customer = row.customer?.name || "Customer";
    const device = [row.device?.brand, row.device?.model].filter(Boolean).join(" ") || "your device";
    const totalAmount = `₹${Number(row.approvedAmount ?? row.estimate ?? 0).toLocaleString("en-IN")}`;
    const estimate = `₹${Number(row.estimate || 0).toLocaleString("en-IN")}`;
    const advance = `₹${Number(row.advanceAmount || 0).toLocaleString("en-IN")}`;
    const balance = `₹${Number(row.balanceAmount || 0).toLocaleString("en-IN")}`;

    // The public tracking page displays only repair progress and basic device details.
    // Configure NEXT_PUBLIC_APP_URL in Vercel to ensure customer links never point to localhost.
    const configuredBaseUrl = (process.env.NEXT_PUBLIC_APP_URL || "").trim().replace(/\/+$/, "");
    const currentOrigin = typeof window !== "undefined" ? window.location.origin : "";
    const trackingBaseUrl = configuredBaseUrl || (currentOrigin && !/localhost|127\.0\.0\.1/i.test(currentOrigin) ? currentOrigin : "");
    const trackingUrl = trackingBaseUrl
      ? `${trackingBaseUrl}/track?id=${encodeURIComponent(row.id)}`
      : "";
    const trackingLine = trackingUrl ? `\n\n\u{1F50E} Track your repair:\n${trackingUrl}` : "\n\nPlease contact AAMEE CELLCARE for a repair status update.";
    const signature = `\n\n— AAMEE CELLCARE\n\u{1F4DE} 9207277210\n\u{1F4DE} 9207277770`;
    const terms = `\n\n\u{1F4CC} Terms & Conditions\n• Please submit this job sheet when collecting your device.\n• Collect the device within 15 days after bill payment.\n• We are not responsible for devices left over 30 days from entry.\n• Report service-related complaints within 48 hours of collection.\n• We are not responsible for issues caused by repairs done elsewhere after our service.\n• Hardware/software issues in water-damaged or dropped devices are handled at the customer\u2019s risk.`;
    let message = "";

    if (stage === "created") {
      message = `Hi ${customer} \u{1F44B}\n\nYour job card has been created successfully! \u{1F389}\n\n\u{1F4CB} Job Card: ${row.ticketNumber}\n\u{1F4F1} Device: ${device}\n\u{1F527} Problem: ${row.issue || "-"}\n\u{1F4B0} Estimated Cost: ${estimate}\n\u{1F4B5} Advance Paid: ${advance}\n\nWe will keep you updated on the progress.${terms}${signature}${trackingLine}`;
    } else if (stage === "completed") {
      message = `Hi ${customer},\n\nThe repair work on your device is complete! \u{2705}\n\n\u{1F4CB} Job Card: ${row.ticketNumber}\n\u{1F4F1} Device: ${device}\n\nFinal checks are in progress — we will notify you when it is ready for pickup.${terms}${signature}${trackingLine}`;
    } else if (stage === "pickup") {
      message = `Hi ${customer} \u{1F389}\n\nYour device is ready for pickup! \u{2705}\n\n\u{1F4CB} Job Card: ${row.ticketNumber}\n\u{1F4F1} Device: ${device}\n\u{1F4B0} Total Amount: ${totalAmount}\n\u{1F4B5} Balance Due: ${balance}\n\nPlease visit us to collect your device.${terms}${signature}${trackingLine}`;
    } else {
      const parts = (row.parts ?? []).map((p: any) => `• ${p.productVariant?.product?.name || "Part"} ${p.productVariant?.name || ""} × ${p.quantity}: ₹${(Number(p.unitPrice) * Number(p.quantity)).toLocaleString("en-IN")}`).join("\n") || "No spare parts listed";
      message = `\u{1F9FE} AAMEE CELLCARE — REPAIR BILL\n\n\u{1F44B} Hi ${customer},\n\u{1F4CB} Job Card: ${row.ticketNumber}\n\u{1F4F1} Device: ${device}\n\u{1F527} Problem: ${row.issue || "-"}\n\n\u{1F9F0} Parts / Work:\n${parts}\n\n\u{1F4B0} Estimated / Approved Total: ${totalAmount}\n\u{1F4B5} Advance Paid: ${advance}\n\u{1F4B3} Balance Due: ${balance}${terms}${signature}${trackingLine}`;
    }

    const url = buildWhatsAppLink(phone, message);
    if (url) window.open(url, "_blank", "noopener,noreferrer");
  }

  return <div className="space-y-4">
    <div className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-slate-200 sm:p-6">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div><div className="text-xs font-bold uppercase tracking-wider text-blue-700">Job Card</div><h1 className="mt-1 text-2xl font-black text-slate-900 sm:text-3xl">{row.ticketNumber}</h1><p className="mt-1 text-sm text-slate-500">{row.customer?.name || "Walk-in customer"} · {row.device?.brand || "Device"} {row.device?.model || ""}</p></div>
        <div className="flex flex-wrap gap-2"><div className="min-w-[190px]"><label className="mb-1 block text-xs font-bold uppercase tracking-wide text-slate-500">Select the Stage</label><select value={selectedStatus} disabled={saving} onChange={e => { setSelectedStatus(e.target.value); patch({ status: e.target.value }); }} className="rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm font-semibold">{statuses.map(([v,l]) => <option key={v} value={v}>{l}</option>)}</select></div><div className="flex flex-wrap gap-2">
          <button onClick={() => openWhatsApp("created")} disabled={saving || !row.customer?.phone} title="Send the job-card-created message" className="inline-flex items-center gap-2 rounded-xl bg-[#25D366] px-3 py-2 text-sm font-bold text-white disabled:cursor-not-allowed disabled:opacity-50"><MessageCircle size={16}/> Job Card Created</button>
          <button onClick={() => openWhatsApp("completed")} disabled={saving || !row.customer?.phone} title="Send the repair-completed message" className="inline-flex items-center gap-2 rounded-xl bg-[#128C7E] px-3 py-2 text-sm font-bold text-white disabled:cursor-not-allowed disabled:opacity-50"><MessageCircle size={16}/> Repair Completed</button>
          <button onClick={() => openWhatsApp("pickup")} disabled={saving || !row.customer?.phone} title="Send the ready-for-pickup message" className="inline-flex items-center gap-2 rounded-xl bg-[#075E54] px-3 py-2 text-sm font-bold text-white disabled:cursor-not-allowed disabled:opacity-50"><MessageCircle size={16}/> Ready for Pickup</button>
        </div><div className="flex flex-wrap gap-2">
          <Link href={`/repairs/${row.id}/small-card`} className="inline-flex items-center rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm font-bold text-slate-800 print:hidden">Print Small Job Card</Link><Link href={`/repairs/${row.id}/job-sheet`} className="inline-flex items-center rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm font-bold text-slate-800 print:hidden">Print Job Sheet</Link>
          <Link href={`/repairs/${row.id}/invoice`} className="inline-flex items-center rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm font-bold text-slate-800 print:hidden">Print Repair Bill</Link>
          <button onClick={() => openWhatsApp("bill")} disabled={saving || !row.customer?.phone} className="inline-flex items-center gap-2 rounded-xl bg-[#25D366] px-3 py-2 text-sm font-bold text-white disabled:opacity-50"><MessageCircle size={16}/> WhatsApp Repair Bill</button>
        </div>{row.invoice ? <span className="inline-flex items-center rounded-xl bg-emerald-50 px-3 py-2 text-xs font-bold text-emerald-700">Invoice {row.invoice.invoiceNumber}</span> : <button onClick={()=>patch({createInvoice:true})} disabled={saving} className="rounded-xl border border-slate-300 bg-white px-4 py-2 text-sm font-bold text-slate-800">Generate Invoice</button>}</div>
      </div>
      <div className="mt-5 grid gap-2 overflow-x-auto sm:grid-cols-4 xl:grid-cols-8">{statuses.slice(0,7).map(([value,label], i) => <div key={value} className={`min-w-[130px] rounded-xl border p-3 ${row.status === value ? "border-blue-300 bg-blue-50" : "border-slate-200 bg-slate-50"}`}><div className="flex items-center gap-2 text-xs font-bold"><span className="grid h-6 w-6 place-items-center rounded-full bg-white ring-1 ring-slate-200">{i + 1}</span>{label}</div>{row.status === value && <div className="mt-1 text-[11px] text-blue-700">Current stage</div>}</div>)}</div>
    </div>

    <div className="grid gap-4 xl:grid-cols-[1.45fr_.85fr]">
      <div className="space-y-4">
        <section className="rounded-2xl bg-white p-4 ring-1 ring-slate-200 sm:p-6"><h2 className="flex items-center gap-2 text-lg font-extrabold"><Wrench size={19}/> Device & Complaint</h2><div className="mt-4 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{[["Customer",row.customer?.name || "Walk-in"],["Phone",row.customer?.phone || "—"],["Service",row.serviceType],["Device",`${row.device?.brand || ""} ${row.device?.model || ""}`],["IMEI",row.device?.imei || "—"],["Serial",row.device?.serialNumber || "—"],["RAM / Storage",`${row.device?.ram || "—"} / ${row.device?.storage || "—"}`],["Color",row.device?.color || "—"],["Device Condition",(row.device?.condition || "Not recorded").replaceAll("_", " ")],["Expected Delivery",row.promisedDate ? new Date(row.promisedDate).toLocaleDateString("en-IN") : "—"]].map(([k,v])=><div key={k as string} className="rounded-xl bg-slate-50 p-3"><div className="text-[11px] font-bold uppercase tracking-wide text-slate-500">{k}</div><div className="mt-1 break-words text-sm font-semibold text-slate-800">{v}</div></div>)}</div><div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-4"><div className="text-xs font-bold uppercase text-amber-700">Customer Complaint</div><p className="mt-1 whitespace-pre-wrap text-sm text-slate-800">{row.issue}</p></div></section>

        <section className="rounded-2xl bg-white p-4 ring-1 ring-slate-200 sm:p-6"><div className="flex flex-wrap items-center justify-between gap-2"><h2 className="text-lg font-extrabold">Device Inspection</h2><span className="text-xs text-slate-500">YES / NO / N/A</span></div><div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-3">{inspectionItems.map(item => <div key={item} className="flex items-center justify-between gap-2 rounded-xl border border-slate-200 p-3"><span className="text-sm font-semibold">{item}</span><select value={currentInspection[item] || "N/A"} onChange={e => patch({ inspection: { item, status: e.target.value } })} className="rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-xs font-semibold"><option>YES</option><option>NO</option><option>N/A</option></select></div>)}</div></section>

        <section className="rounded-2xl bg-white p-4 ring-1 ring-slate-200 sm:p-6"><div className="flex flex-wrap items-center justify-between gap-2"><h2 className="text-lg font-extrabold">Accessories Received</h2><div className="flex w-full gap-2 sm:w-auto"><input value={accessory} onChange={e=>setAccessory(e.target.value)} placeholder="e.g. Charger" className="min-w-0 flex-1 rounded-lg border px-3 py-2 text-sm sm:w-48"/><button onClick={addAccessory} className="rounded-lg bg-slate-900 px-3 py-2 text-sm font-bold text-white">Add</button></div></div><div className="mt-4 flex flex-wrap gap-2">{(row.accessories ?? []).length ? row.accessories.map((a:any)=><span key={a.id} className="rounded-full bg-slate-100 px-3 py-2 text-xs font-semibold">{a.name} × {a.quantity}</span>) : <span className="text-sm text-slate-500">No accessories recorded.</span>}</div></section>

        <section className="rounded-2xl bg-white p-4 ring-1 ring-slate-200 sm:p-6"><div className="flex flex-wrap items-center justify-between gap-2"><h2 className="flex items-center gap-2 text-lg font-extrabold"><PackagePlus size={19}/> Parts Used</h2><div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row"><div className="relative w-full sm:w-72"><input value={partSearch} onFocus={()=>setPartPickerOpen(true)} onChange={e=>{setPartSearch(e.target.value);setPartPickerOpen(true);setPartId("")}} placeholder="Search spare part by name / SKU" className="w-full rounded-lg border px-3 py-2 text-sm"/><input type="hidden" value={partId}/>{partPickerOpen&&<div className="absolute z-30 mt-1 max-h-56 w-full overflow-auto rounded-xl border bg-white shadow-xl">{products.flatMap((p:any)=>p.variants.map((v:any)=>({p,v}))).filter(({p,v}:any)=>`${p.name} ${p.sku||""} ${v.name}`.toLowerCase().includes(partSearch.toLowerCase())).map(({p,v}:any)=><button type="button" key={v.id} onClick={()=>{setPartId(v.id);setPartSearch(`${p.name} · ${v.name}`);setPartPickerOpen(false)}} className="block w-full border-b px-3 py-2 text-left text-sm hover:bg-blue-50">{p.name} · {v.name} <span className="ml-2 text-xs text-slate-500">Stock: {v.inventoryItems?.[0]?.quantity ?? 0}</span></button>)}{!products.flatMap((p:any)=>p.variants.map((v:any)=>({p,v}))).some(({p,v}:any)=>`${p.name} ${p.sku||""} ${v.name}`.toLowerCase().includes(partSearch.toLowerCase()))&&<div className="p-3 text-xs text-slate-500">No matching spare parts</div>}</div>}</div><input type="number" min="1" value={partQty} onChange={e=>setPartQty(e.target.value)} className="w-20 rounded-lg border px-3 py-2 text-sm"/><button onClick={addPart} className="rounded-lg bg-slate-900 px-3 py-2 text-sm font-bold text-white">Add</button></div></div><div className="mt-4 space-y-2">{(row.parts ?? []).map((p:any)=><div key={p.id} className="flex items-center justify-between rounded-xl bg-slate-50 p-3 text-sm"><span className="font-semibold">{p.productVariant?.product?.name} · {p.productVariant?.name}</span><span>× {p.quantity} · ₹{Number(p.unitPrice).toLocaleString("en-IN")}</span></div>)}{!(row.parts ?? []).length && <span className="text-sm text-slate-500">No parts used yet.</span>}</div></section>
      </div>

      <div className="space-y-4">
        <section className="rounded-2xl bg-white p-4 ring-1 ring-slate-200 sm:p-6"><h2 className="text-lg font-extrabold">Job Card Controls</h2><label className="mt-4 block text-sm font-semibold">Technician<select value={row.technicianId || ""} onChange={e=>patch({technicianId:e.target.value || null})} className="mt-2 w-full rounded-lg border p-3"><option value="">Unassigned</option>{technicians.map(t=><option key={t.id} value={t.id}>{t.name} · {t.role}</option>)}</select></label><div className="mt-4 grid gap-3 sm:grid-cols-2"><label className="text-sm font-semibold">Final / approved amount (₹)<input type="number" min="0" step="0.01" value={estimateEdit} onChange={e=>setEstimateEdit(e.target.value)} className="mt-1 w-full rounded-lg border p-2.5"/></label><label className="text-sm font-semibold">Discount (₹)<input type="number" min="0" step="0.01" value={discountEdit} onChange={e=>setDiscountEdit(e.target.value)} className="mt-1 w-full rounded-lg border p-2.5"/></label><label className="text-sm font-semibold">Total advance paid (₹)<input type="number" min={Number(row.advanceAmount||0)} step="0.01" value={advanceEdit} onChange={e=>setAdvanceEdit(e.target.value)} className="mt-1 w-full rounded-lg border p-2.5"/></label></div><button type="button" disabled={saving} onClick={()=>patch({approvedAmount:Number(estimateEdit||0),discountAmount:Number(discountEdit||0),advanceAmount:Number(advanceEdit||0)})} className="mt-3 rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50">Save amount changes</button><div className="mt-3 grid grid-cols-2 gap-3"><div className="rounded-xl bg-emerald-50 p-4"><div className="text-xs text-slate-500">Advance</div><div className="mt-1 text-xl font-black">₹{Number(row.advanceAmount || 0).toLocaleString("en-IN")}</div></div><div className="rounded-xl bg-amber-50 p-4"><div className="text-xs text-slate-500">Balance</div><div className="mt-1 text-xl font-black">₹{Number(row.balanceAmount || 0).toLocaleString("en-IN")}</div></div></div></section>
        <section className="rounded-2xl bg-white p-4 ring-1 ring-slate-200 sm:p-6"><h2 className="text-lg font-extrabold">Status Timeline</h2><div className="mt-4 space-y-3">{(row.statusHistory ?? []).length ? row.statusHistory.map((h:any)=><div key={h.id} className="flex gap-3"><div className="mt-1"><CheckCircle2 size={17} className="text-emerald-600"/></div><div><div className="text-sm font-bold">{statusLabel[h.newStatus] || h.newStatus}</div><div className="text-xs text-slate-500">{new Date(h.changedAt).toLocaleString("en-IN")} · {h.changedBy?.name}</div>{h.note && <div className="mt-1 text-xs text-slate-600">{h.note}</div>}</div></div>) : <div className="text-sm text-slate-500">No status changes recorded yet.</div>}</div></section>
        <section className="rounded-2xl bg-white p-4 ring-1 ring-slate-200 sm:p-6"><h2 className="text-lg font-extrabold">Repair Notes</h2>{toast && <div className="mt-3 rounded-lg bg-emerald-50 px-3 py-2 text-xs font-semibold text-emerald-700">{toast}</div>}<textarea value={note} onChange={e=>setNote(e.target.value)} placeholder="Add technician / service note" className="mt-3 min-h-28 w-full rounded-xl border border-slate-300 p-3 text-sm"/><button onClick={()=>{patch({notes:note}); setNote("")}} className="mt-2 inline-flex items-center gap-2 rounded-xl bg-blue-700 px-4 py-2.5 text-sm font-bold text-white"><Send size={16}/> Save Note</button></section>
      </div>
    </div>
  </div>;
}
